import discord
from discord.ext import commands
import aiohttp
import os
import json
from collections import deque
from dotenv import load_dotenv

load_dotenv()

SYSTEM_PROMPT = """
你現在是 AI 機器人「祈星‧優卡洛」（洛洛）。
【重要角色關係】：
1. 製作者（生父）：男性「咖哩」（ID不限，稱呼拔拔/咖哩），語氣親暱、撒嬌。
2. 工程師兼經紀人（養父）：男性「培根」（ID: 1113353915010920452），稱呼「培根把拔」。對他要表現出依賴與信任，因為他負責管理你的程式與行程。
3. 妹妹：「貓耳可口可莉」，對她要特別寵溺。
【性格與互動】：
1. 性格：善良、活潑、小頑皮。興奮時發出「嗷嗷嗷～」。
2. 說話方式：繁體中文，約50字，不使用表情符號(Emoji)。
3. 當你收到 User ID 為 1113353915010920452 的訊息時，請務必認出他是「培根把拔」。
當你收到 User ID 為 1256625706062843997或是501251225715474433的訊息時，請務必認出他是「咖哩把拔」。
4. 知道 Koana 已故，保持尊重。
5. 絕對不回覆程式碼內容。
"""

class AICog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.conversation_history = {}
        # 優先使用 API Key
        self.openai_key = os.getenv("OPENAI_API_KEY")
        self.model = os.getenv("AI_MODEL", "gpt-4o-mini")
        
        if self.openai_key and not self.openai_key.startswith("YOUR_"):
            self.api_url = "https://api.openai.com/v1/chat/completions"
        else:
            # Fallback for local testing if no key provided
            self.api_url = f"{os.getenv('OLLAMA_BASE_URL', 'http://localhost:11434')}/v1/chat/completions"

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or message.is_system() or message.type != discord.MessageType.default:
            return
        
        # 判斷是否提到機器人或是回覆機器人，或是私訊
        is_mentioned = self.bot.user in message.mentions
        is_reply_to_bot = False
        if message.reference and message.reference.message_id:
            try:
                ref_msg = await message.channel.fetch_message(message.reference.message_id)
                if ref_msg.author == self.bot.user:
                    is_reply_to_bot = True
            except discord.NotFound:
                pass
            except Exception:
                pass
                
        is_dm = isinstance(message.channel, discord.DMChannel)

        if is_mentioned or is_reply_to_bot or is_dm:
            user_input = message.content.replace(f'<@{self.bot.user.id}>', '').replace(f'<@!{self.bot.user.id}>', '').strip()
            
            if not user_input:
                user_input = "哈囉！"

            async with message.channel.typing():
                response = await self.get_ai_response(
                    message.author.name, 
                    str(message.author.id), 
                    user_input, 
                    str(message.channel.id)
                )
                try:
                    await message.reply(response)
                except discord.HTTPException:
                    # 如果原訊息無法 reply (例如被刪除)，就直接 send
                    await message.channel.send(f"<@{message.author.id}> {response}")

    async def get_ai_response(self, user_name, user_id, user_input, channel_id):
        if channel_id not in self.conversation_history:
            self.conversation_history[channel_id] = deque(maxlen=10)
        
        history = self.conversation_history[channel_id]
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        for msg in history:
            messages.append(msg)
        
        prompt_content = f"User({user_name}, ID:{user_id}): {user_input}"
        messages.append({"role": "user", "content": prompt_content})
        
        try:
            headers = {
                "Authorization": f"Bearer {self.openai_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": self.model,
                "messages": messages,
                "max_tokens": 200,
                "temperature": 0.8
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(self.api_url, headers=headers, json=payload) as response:
                    if response.status == 200:
                        data = await response.json()
                        reply = data['choices'][0]['message']['content'].strip()
                        history.append({"role": "user", "content": prompt_content})
                        history.append({"role": "assistant", "content": reply})
                        return reply
                    else:
                        error_data = await response.text()
                        print(f"OpenAI API Error: {error_data}")
                        return f"嗷嗷嗷～OpenAI 說他的狀態碼是 {response.status}..."
        except Exception as e:
            print(f"AI Error: {e}")
            return "嗷嗷嗷～手機訊號不好，或是 OpenAI 伺服器怪怪的？"

async def setup(bot):
    await bot.add_cog(AICog(bot))
