@echo off
set "ADB_EXE=D:\win11\下載\ADB-and-Fastboot++_v1.1.1-Portable(1)\ADB and Fastboot++ v1.1.1 Portable\adb.exe"
set "PROJECT_FOLDER=d:\win11\桌面\yokaro"

echo 📦 [ 優卡洛‧祈星 ] 正在推送檔案...
echo 🚨 如果提示 adb 找不到，請確保 ADB 資料夾路徑正確喔！

:: 建立暫存
"%ADB_EXE%" shell "mkdir -p /sdcard/yokaro_tmp"

:: 推送
"%ADB_EXE%" push "%PROJECT_FOLDER%\yokaro.py" /sdcard/yokaro_tmp/
"%ADB_EXE%" push "%PROJECT_FOLDER%\.env" /sdcard/yokaro_tmp/
"%ADB_EXE%" push "%PROJECT_FOLDER%\requirements.txt" /sdcard/yokaro_tmp/
"%ADB_EXE%" push "%PROJECT_FOLDER%\start.sh" /sdcard/yokaro_tmp/
"%ADB_EXE%" push "%PROJECT_FOLDER%\setup_termux.sh" /sdcard/yokaro_tmp/
"%ADB_EXE%" shell "rm -rf /sdcard/yokaro_tmp/cogs"
"%ADB_EXE%" push "%PROJECT_FOLDER%\cogs" /sdcard/yokaro_tmp/cogs

:: 同步
echo 🔄 正在同步到 Termux Home 目錄 (~/yokaro)...
"%ADB_EXE%" shell "mkdir -p /data/data/com.termux/files/home/yokaro"
"%ADB_EXE%" shell "cp -rf /sdcard/yokaro_tmp/* /data/data/com.termux/files/home/yokaro/"
"%ADB_EXE%" shell "rm -rf /sdcard/yokaro_tmp"

echo ✅ 推送完成！嗷嗷嗷～
echo 💡 下一步：手機端輸入 cd ~/yokaro && ./start.sh
pause
