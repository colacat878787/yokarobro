#!/bin/bash

# Termux 基礎依賴安裝
echo "📦 正在安裝 Termux 基礎套件..."
pkg update && pkg upgrade -y
pkg install -y python libffi openssl ffmpeg nodejs build-essential git \
               libjpeg-turbo libpng zlib libsodium libopus

# Python 依賴安裝
echo "🐍 正在安裝 Python 依賴函式庫 (包括 Pillow & Discord)..."
# 注意：有些庫在 Termux 上透過 pip 安裝很慢或會失敗，建議先用 pkg 安裝一部份
pkg install -y python-pillow python-cryptography

# 建立並進入虛擬環境 (避免 PEP 668 報錯)
if [ ! -d "venv" ]; then
    echo "⚙️ 正在建立自動化虛擬環境..."
    python -m venv venv
fi
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Ollama & Ubuntu 環境設定
echo "🛠️ 檢查 proot-distro 環境..."
pkg install -y proot-distro

# 檢查是否已安裝 ubuntu，若無則安裝
if ! proot-distro list | grep -q "ubuntu.*installed"; then
    echo "正在下載 Ubuntu 映像檔..."
    proot-distro install ubuntu
else
    echo "✅ Ubuntu 已經備妥。"
fi

# 自動在 Ubuntu 中安裝 Ollama
echo "正在自動為 Ubuntu 虛擬機安裝 Ollama (這可能需要點時間)..."
# 檢查 Ubuntu 內是否已安裝 ollama
if ! proot-distro login ubuntu -- bash -c "command -v ollama" > /dev/null 2>&1; then
    proot-distro login ubuntu -- bash -c "curl -fsSL https://ollama.com/install.sh | sh"
else
    echo "✅ Ollama 已經在 Ubuntu 中安裝過囉。"
fi

echo "✅ 基礎依賴安裝完成！"
echo ""
echo "==== 🎬 接下來你只需要兩步 ═══"
echo "1. 輸入: proot-distro login ubuntu"
echo "2. 輸入: ollama serve & (啟動引擎)"
echo "3. 下載模型並測試: ollama run llama3"
echo "4. 測試完輸入 'exit'，最後跑 './start.sh'！"
echo "=========================================="
