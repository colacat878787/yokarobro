#!/bin/bash

# 顏色設定
GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo -e "${GREEN}==============================${NC}"
VERSION="2.0.8 - Audio Fix Update [2026-04-05]"
echo -e "${GREEN}   優卡洛 啟動器 - $VERSION   ${NC}"
echo -e "${GREEN}==============================${NC}"

# 檢查是否在正確的 Home 目錄 (防止在 /sdcard 執行導致權限問題)
if [[ "$PWD" == *"/sdcard/"* ]]; then
    echo "❌ 錯誤：偵測到你在 SD 卡目錄執行！"
    echo "請將檔案搬移到 Termux Home (~/yokaro) 再執行。"
    exit 1
fi

echo "🔍 正在檢查系統套件..."
missing_pkgs=()
command -v ffmpeg >/dev/null 2>&1 || missing_pkgs+=("ffmpeg")
command -v proot-distro >/dev/null 2>&1 || missing_pkgs+=("proot-distro")

if [ ${#missing_pkgs[@]} -ne 0 ]; then
    echo "❌ 錯誤：缺少系統套件：${missing_pkgs[*]}"
    echo "💡 請先執行: bash setup_termux.sh"
    exit 1
fi

# 檢查是否已安裝依賴 (Python venv)
if [ ! -d "venv" ]; then
    echo "⚙️ 開始建立虛擬環境 (這可能需要幾分鐘)..."
    python -m venv venv
fi

echo "🔄 進入虛擬環境中..."
source venv/bin/activate

echo "📦 正在檢查並確保所有套件均已安裝..."
pip install --upgrade pip > /dev/null 2>&1
pip install -r requirements.txt

# 控制台標題資訊
echo "✅ 環境就緒，正在啟動機器人本體..."

# 無限循環，實現斷線/重啟功能
until python yokaro.py; do
    echo "⚠️ 機器人中斷，5秒後自動重啟..."
    sleep 5
done

echo "✅ 機器人已正常結束。"
